var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });

function preload() {
	// preload assets
}

function create() {
	// place your assets
}

function update() {
	// run game loop
}


// Nathan Altice
// Updated: 4/16/19
// Phaser movement
// Demonstrates physics-based movement w/ variable jumps
// this.jumps variable allows you to set double, triple, etc. jumps
// Inspired by and adapted from Game Mechanic Explorer https://gamemechanicexplorer.com

// Play state
var Play = function() {
	// define constants
	this.HALFSCALE = 0.5;
	this.MAX_X_VELOCITY = 500;	// measured in pixels/second
	this.MAX_Y_VELOCITY = 5000;
	this.ACCELERATION = 1500;
	this.DRAG = 600;			// note that DRAG < ACCELERATION (to create sliding)
	this.GRAVITY = 2600;
	this.JUMP_SPEED = -700;	// negative y-values jump up
};
Play.prototype = {
	preload: function() {
		// set load path and load assets
		this.load.path = 'img/';
		this.load.atlas('atlas', 'kenny_sheet.png', 'kenny_sheet.json');
		this.load.image('arrowKey', 'arrowKey.png');
	},
	create: function() {
		// background color
		game.stage.backgroundColor = "#223344";

		// set up world physics
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.physics.arcade.gravity.y = this.GRAVITY;

		// draw grid lines (do this now so they're behind other sprites)
		this.drawGridLines();

		// set up our alien sprite
		this.alien = this.add.sprite(this.world.centerX, this.world.centerY, 'atlas', 'side');
		this.alien.anchor.set(0.5);
		this.alien.scale.setTo(this.HALFSCALE);
		// set up alien physics
		game.physics.enable(this.alien, Phaser.Physics.ARCADE);
		this.alien.body.collideWorldBounds = true;
		// cap the alien's max velocity (x, y)
		// make sure you don't set your jump velocity higher than max y velocity,
		// otherwise you'll never exceed that threshold
		this.alien.body.maxVelocity.x = this.MAX_X_VELOCITY;
		this.alien.body.maxVelocity.y = this.MAX_Y_VELOCITY;
		// add drag to slow the physics body while not accelerating
		this.alien.body.drag.setTo(this.DRAG, 0);
		// set up alien animations
		// .add('key', [frames], frameRate, loop)
		// .generateFrameNames('prefix', start, stop, 'suffix', zeroPad) -> returns array
		// this handles atlas names in format: walk0001 - walk0011
		this.alien.animations.add('walk', Phaser.Animation.generateFrameNames('walk', 1, 11, '', 4), 30, true);
		this.alien.animations.add('idle', ['front'], 30, false);
		this.alien.animations.add('jump', ['jump'], 30, false);

		// set up ground
		this.ground = game.add.group();
		for(let i = 0; i < game.width; i += 35) {
			var groundTile = game.add.sprite(i, game.height - 35, 'atlas', 'block');
			groundTile.scale.setTo(this.HALFSCALE);
			game.physics.enable(groundTile, Phaser.Physics.ARCADE);
			groundTile.body.immovable = true;
			groundTile.body.allowGravity = false;
			this.ground.add(groundTile);
		}

		// add arrows
		this.upKey = game.add.sprite(64, 32, 'arrowKey');
		this.leftKey = game.add.sprite(32, 64, 'arrowKey');
		this.downKey = game.add.sprite(64, 64, 'arrowKey');
		this.rightKey = game.add.sprite(96, 64, 'arrowKey');
		this.upKey.anchor.set(0.5);
		this.leftKey.anchor.set(0.5);
		this.downKey.anchor.set(0.5);
		this.rightKey.anchor.set(0.5);
		this.leftKey.rotation = Math.PI/2*3;
		this.downKey.rotation = Math.PI;
		this.rightKey.rotation = Math.PI/2;

		// init debug toggle
		this.debug = false;
	},
	update: function() {
		// check collisions
		this.game.physics.arcade.collide(this.alien, this.ground);

		// check keyboard input
		if(this.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
			this.alien.body.acceleration.x = -this.ACCELERATION;
			this.alien.scale.x = -this.HALFSCALE; 	// flip sprite
			this.alien.animations.play('walk');
			this.leftKey.tint = 0xFACADE;			// tint keyboard key
		} else if (this.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
			this.alien.body.acceleration.x = this.ACCELERATION;
			this.alien.scale.x = this.HALFSCALE; 	// re-orient sprite
			this.alien.animations.play('walk');
			this.rightKey.tint = 0xFACADE;			// tint keyboard key
		} else {
			// set acceleration to 0 (so DRAG will take over)
			this.alien.body.acceleration.x = 0;
			this.alien.animations.play('idle');		
			this.leftKey.tint = 0xFFFFFF;			// un-tint keys
			this.rightKey.tint = 0xFFFFFF;
		}

		// check if alien is grounded
	    this.isGrounded = this.alien.body.touching.down;
	    // if so, we have jumps to spare
	    // change this.jumps to create double, triple, etc. jumps 🤾‍♀️
	    if(this.isGrounded) {
	    	this.jumps = 2;
	    	this.jumping = false;
	    } else {
	    	this.alien.animations.play('jump');
	    }
	    // allow steady velocity change up to a certain key down duration
	    if(this.jumps > 0 && this.input.keyboard.downDuration(Phaser.Keyboard.UP, 150)) {
	        this.alien.body.velocity.y = this.JUMP_SPEED;
	        this.jumping = true;
	        this.upKey.tint = 0xFACADE;
	    } else {
	    	this.upKey.tint = 0xFFFFFF;
	    }
	    // finally, letting go of the UP key subtracts a jump
	    if(this.jumping && this.input.keyboard.upDuration(Phaser.Keyboard.UP)) {
	    	this.jumps--;
	    	this.jumping = false;
	    }

	    // debug toggle
	    if(this.input.keyboard.justPressed(Phaser.Keyboard.T)) {
	    	this.debug = !this.debug;
	    }
	},
	drawGridLines: function() {
		// create a bitmap the same size as the stage
    	var bitmap = game.add.bitmapData(this.game.width, this.game.height);

	    // use the canvas context to draw lines
	    for(let y = this.game.height-70; y >= 35; y -= 35) {
	        bitmap.context.beginPath();
	        bitmap.context.strokeStyle = 'rgba(255, 255, 255, 0.5)';
	        bitmap.context.moveTo(0, y);
	        bitmap.context.lineTo(this.game.width, y);
	        bitmap.context.stroke();
	    }

	    this.game.add.image(0, 0, bitmap);
	},
	render: function() {
		if(this.debug) {
			game.debug.bodyInfo(this.alien, 32, 128);
			game.debug.body(this.alien);
			game.debug.text('Jumps left: '+this.jumps, 32, 232, 'yellow');
			game.debug.text('Jumping: '+this.jumping, 32, 248, 'yellow');
		}
		game.debug.text('Press \'T\' to toggle debug text', 32, game.height - 17);	
	}
};

// define game, add states, and start Preloader
var game = new Phaser.Game(840, 525, Phaser.AUTO, 'phaser');
game.state.add('Play', Play);
game.state.start('Play');
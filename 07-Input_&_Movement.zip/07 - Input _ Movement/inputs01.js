// Nathan Altice
// Updated: 4/15/19
// Phaser movement
// Demonstrates simple physics-based velocity movement (w/ texture atlas animation)
// Inspired by and adapted from Game Mechanic Explorer https://gamemechanicexplorer.com

// Play state
var Play = function() {
	// define constants
	this.HALFSCALE = 0.5;
	this.MAX_VELOCITY = 500;	// measured in pixels/second
	this.GRAVITY = 2600;
};
Play.prototype = {
	preload: function() {
		// set load path and load assets
		this.load.path = 'img/';
		this.load.atlas('atlas', 'kenny_sheet.png', 'kenny_sheet.json');
		this.load.image('arrowKey', 'arrowKey.png');
	},
	create: function() {
		// make it blue
		game.stage.backgroundColor = "#CCC";

		// set up world physics
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.physics.arcade.gravity.y = this.GRAVITY;

		// set up our alien sprite
		this.alien = this.add.sprite(this.world.centerX, this.world.centerY, 'atlas', 'side');
		this.alien.anchor.set(0.5);
		this.alien.scale.setTo(this.HALFSCALE);
		// set up alien physics
		game.physics.enable(this.alien, Phaser.Physics.ARCADE);
		this.alien.body.collideWorldBounds = true;
		// set up alien animations
		// .add('key', [frames], frameRate, loop)
		// .generateFrameNames('prefix', start, stop, 'suffix', zeroPad) -> returns array
		// this handles atlas names in format: walk0001 - walk0011
		this.alien.animations.add('walk', Phaser.Animation.generateFrameNames('walk', 1, 11, '', 4), 30, true);
		this.alien.animations.add('idle', ['front'], 30, false);

		// set up fly sprite
		this.fly = this.add.sprite(this.world.centerX + 100, this.world.centerY, 'atlas', 'fly_normal');
		this.fly.anchor.set(0.5);
		this.fly.scale.setTo(this.HALFSCALE);
		this.fly.animations.add('flying', ['fly_normal', 'fly_fly'], 30, true);
		// start flying animation now since fly will always be...flying
		this.fly.animations.play('flying'); 

		// set up ground
		this.ground = game.add.group();
		for(let i = 0; i < game.width; i += 35) {
			var groundTile = game.add.sprite(i, game.height - 35, 'atlas', 'block');
			groundTile.scale.setTo(this.HALFSCALE);
			game.physics.enable(groundTile, Phaser.Physics.ARCADE);
			groundTile.body.immovable = true;
			groundTile.body.allowGravity = false;
			this.ground.add(groundTile);
		}

		// add arrows
		this.upKey = game.add.sprite(64, 32, 'arrowKey');
		this.leftKey = game.add.sprite(32, 64, 'arrowKey');
		this.downKey = game.add.sprite(64, 64, 'arrowKey');
		this.rightKey = game.add.sprite(96, 64, 'arrowKey');
		this.upKey.anchor.set(0.5);
		this.leftKey.anchor.set(0.5);
		this.downKey.anchor.set(0.5);
		this.rightKey.anchor.set(0.5);
		this.leftKey.rotation = Math.PI/2*3;
		this.downKey.rotation = Math.PI;
		this.rightKey.rotation = Math.PI/2;

		// init debug toggle
		this.debug = false;
	},
	update: function() {
		// check collisions
		this.game.physics.arcade.collide(this.alien, this.ground);

		// check keyboard input
		if(this.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
			this.alien.body.velocity.x = -this.MAX_VELOCITY;
			this.alien.scale.x = -this.HALFSCALE; 	// flip sprite
			this.alien.animations.play('walk');
			this.leftKey.tint = 0xFACADE;			// tint keyboard key
		} else if (this.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
			this.alien.body.velocity.x = this.MAX_VELOCITY;
			this.alien.scale.x = this.HALFSCALE; 	// re-orient sprite
			this.alien.animations.play('walk');
			this.rightKey.tint = 0xFACADE;			// tint keyboard key
		} else {
			// make sure the alien stops
			this.alien.body.velocity.x = 0;
			this.alien.animations.play('idle');		
			this.leftKey.tint = 0xFFFFFF;			// un-tint keys
			this.rightKey.tint = 0xFFFFFF;
		}

		// debug toggle
	    if(this.input.keyboard.justPressed(Phaser.Keyboard.T)) {
	    	this.debug = !this.debug;
	    }
	},
	render: function() {
		if(this.debug) {
			game.debug.bodyInfo(this.alien, 32, 128);
			game.debug.body(this.alien);
		}
		game.debug.text('Press \'T\' to toggle debug text', 32, game.height - 17);	
	}
};

// define game, add states, and start Preloader
var game = new Phaser.Game(840, 525, Phaser.AUTO, 'phaser');
game.state.add('Play', Play);
game.state.start('Play');
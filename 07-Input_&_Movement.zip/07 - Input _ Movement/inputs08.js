// Nathan Altice
// Updated: 4/17/19
// Phaser movement
// Demonstrates Asteroids-style ship movement (w/ texture atlas XML loading)
// Uses accelerateToObject to create a "gravitational pull" in the center
// Inspired by and adapted from Game Mechanic Explorer https://gamemechanicexplorer.com

// Play state
var Play = function() {
	// define constants
	this.HALFSCALE = 0.5;
	this.MAX_VELOCITY = 500;	// measured in pixels/second
	this.ANG_VELOCITY = 180;	// degrees/second
	this.ACCELERATION = 200;
	this.DRAG = 50;
	this.VOID_ACCELERATION = 100;
};
Play.prototype = {
	preload: function() {
		// set load path and load assets
		this.load.path = 'img/';
		this.load.atlasXML('atlas', 'shooter_sheet.png', 'shooter_sheet.xml');
		this.load.image('arrowKey', 'arrowKey.png');
	},
	create: function() {
		// make it blue
		game.stage.backgroundColor = "#111";

		// set up world physics
		game.physics.startSystem(Phaser.Physics.ARCADE);

		// set up our ship sprite
		this.ship = this.add.sprite(this.game.width/4, this.world.centerY, 'atlas', 'spaceShips_003.png');
		this.ship.anchor.set(0.5);
		this.ship.scale.setTo(this.HALFSCALE);

		// set up ship physics
		game.physics.enable(this.ship, Phaser.Physics.ARCADE);
		this.ship.body.maxVelocity.setTo(this.MAX_VELOCITY, this.MAX_VELOCITY);
		this.ship.body.drag.setTo(this.DRAG, this.DRAG);
		// setSize(width, height, offsetX, offsetY) - offsets are from upper-left of sprite texture
		this.ship.body.setSize(32,32,32,32);

		// set up our enemy ship sprite
		this.enemy = this.add.sprite(this.game.width/4*3, this.world.centerY, 'atlas', 'spaceShips_008.png');
		this.enemy.anchor.set(0.5);
		this.enemy.scale.setTo(this.HALFSCALE);

		// set up enemy ship physics
		game.physics.enable(this.enemy, Phaser.Physics.ARCADE);
		this.enemy.body.maxVelocity.setTo(this.MAX_VELOCITY, this.MAX_VELOCITY);
		this.enemy.body.drag.setTo(this.DRAG, this.DRAG);
		// setSize(width, height, offsetX, offsetY) - offsets are from upper-left of sprite texture
		this.enemy.body.setSize(32,32,32,32);

		// set up our meteor sprite
		this.meteor = this.add.sprite(this.world.centerX, this.world.centerY, 'atlas', 'spaceMeteors_003.png');
		this.meteor.anchor.set(0.5);
		this.meteor.scale.setTo(this.HALFSCALE);
		this.meteor.tint = 0xffbf00;

		// set up meteor physics
		game.physics.enable(this.meteor, Phaser.Physics.ARCADE);
		// setSize(width, height, offsetX, offsetY) - offsets are from upper-left of sprite texture
		//this.meteor.body.setSize(150,150,32,48);
		this.meteor.body.immovable = true;
		// accelerateToObject(displayObject, destination [, speed] [, xSpeedMax] [, ySpeedMax])
		game.physics.arcade.accelerateToObject(this.ship, this.meteor, this.VOID_ACCELERATION, this.MAX_VELOCITY/5, this.MAX_VELOCITY/5);
		game.physics.arcade.accelerateToObject(this.enemy, this.meteor, this.VOID_ACCELERATION, this.MAX_VELOCITY/5, this.MAX_VELOCITY/5);

		// add arrows
		this.upKey = game.add.sprite(64, 32, 'arrowKey');
		this.leftKey = game.add.sprite(32, 64, 'arrowKey');
		this.downKey = game.add.sprite(64, 64, 'arrowKey');
		this.rightKey = game.add.sprite(96, 64, 'arrowKey');
		this.upKey.anchor.set(0.5);
		this.leftKey.anchor.set(0.5);
		this.downKey.anchor.set(0.5);
		this.rightKey.anchor.set(0.5);
		this.leftKey.rotation = Math.PI/2*3;
		this.downKey.rotation = Math.PI;
		this.rightKey.rotation = Math.PI/2;

		// init debug toggle
		this.debug = false;

		// get the special cursor key object
		this.cursors = this.input.keyboard.createCursorKeys();
	},
	update: function() {
		// check object edge bounds
		this.checkEdgeBounds(this.ship);
		this.checkEdgeBounds(this.enemy);

		// check collisions
		this.game.physics.arcade.collide(this.ship, this.enemy);
		this.game.physics.arcade.collide(this.ship, this.meteor);
		this.game.physics.arcade.collide(this.enemy, this.meteor);

		// rotate meteor
		this.meteor.rotation += 5;

		// check keyboard input
		if(this.cursors.left.isDown) {
			this.ship.body.angularVelocity = -this.ANG_VELOCITY;	// spin ship left
			this.leftKey.tint = 0xFACADE;			// tint keyboard key
		} else if (this.cursors.right.isDown) {
			this.ship.body.angularVelocity = this.ANG_VELOCITY;	// spin ship right
			this.rightKey.tint = 0xFACADE;			// tint keyboard key
		} else {
			// make sure the ship stops spinning
			this.ship.body.angularVelocity = 0;	
			this.leftKey.tint = 0xFFFFFF;			// un-tint keys
			this.rightKey.tint = 0xFFFFFF;
		}

		if(this.cursors.up.isDown) {
			// accelerationFromRotation(rotation in radians, speed in px/sec^2, point x/y acceleration)
			this.physics.arcade.accelerationFromRotation(this.ship.rotation-Math.PI/2*3, this.ACCELERATION, this.ship.body.acceleration);
		} 

		// debug toggle
	    if(this.input.keyboard.justPressed(Phaser.Keyboard.T)) {
	    	this.debug = !this.debug;
	    }
	},
	render: function() {
		if(this.debug) {
			game.debug.bodyInfo(this.ship, 32, 128);
			game.debug.body(this.ship);
			game.debug.body(this.enemy);
			game.debug.body(this.meteor);
			game.debug.text('Ang. Velocity: ' + this.ship.body.angularVelocity, 32, 232, 'yellow');
			}
			game.debug.text('Press \'T\' to toggle debug text', 32, game.height - 17);	
	},
	checkEdgeBounds: function(obj) {
		// cleanly wrap objects around screen edges
		if(obj.x > game.width + obj.width) obj.x = 0 - obj.width;
		if(obj.x < 0 - obj.width) obj.x = game.width + obj.width;
		if(obj.y > game.height + obj.height) obj.y = 0 - obj.height;
		if(obj.y < 0 - obj.height) obj.y = game.height + obj.height;
	}
};

// define game, add states, and start Preloader
var game = new Phaser.Game(840, 525, Phaser.AUTO, 'phaser');
game.state.add('Play', Play);
game.state.start('Play');
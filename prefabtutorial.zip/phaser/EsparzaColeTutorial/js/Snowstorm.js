function Snowstorm( game, key, frame, scale, rotation )
{
	//call to Phaser.Sprite
	//new Sprite( game, x, y, key, frame )
	Phaser.Sprite.call( this, game, 0, 0, key, frame );

	//add properties
	this.anchor.set( 0.5 );
	this.body.gravity.y = 400;
	this.scale.x = scale;
	this.scale.y = scale;
	this.rotation = rotation;

	game.physics.enbale( this );
	this.body.angularVelocity = game.rnd.integerInRange( -180, 180 );

}

Snowstorm.prototype = Object.create( Phaser.Sprite.prototype );
Snowstorm.prototype.constructor = Snowstorm;

Snowstorm.prototype.update = function()
{
	if( game.input.keyboard.isDown( Phaser.Keyboard.R ) )
	{

	}
}